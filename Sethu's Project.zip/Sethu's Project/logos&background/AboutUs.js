$(document).ready(function () {
    $.getJSON("AboutUs.json", function (data) {
        console.log(data);
        $.each(data.AboutUs, function (index, each) {
            $("#AllContent" + index).append("<img src=" + each.photo + " width='150px' height='200px' />");
            $("#AllContent" + index).append("<h1 >" + each.name + "</h1>");
            $("#AllContent" + index).append("<p >" + each.designation + "</p>");
            $("#AllContent" + index).append("<p >" + each.desc + "</p>");
            $("#AllContent" + index).append("<p >" + each.mail + "</p>");
            
        });
    });
});