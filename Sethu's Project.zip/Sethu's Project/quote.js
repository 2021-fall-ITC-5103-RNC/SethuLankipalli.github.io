function validation() {
    var firstname = document.getElementById("first_name").value;
    var lastname = document.getElementById("last_name").value;
    var email = document.getElementById("email").value;
    var phone = document.getElementById("phone").value;
    var place = document.getElementById("placename").value;
    var comments = document.getElementById("description").value;
    var error_first = document.getElementById("errorfirstname");
    var error_last = document.getElementById("errorlastname");
    var error_email = document.getElementById("erroremail");
    var error_phone = document.getElementById("errorphone");
    var error_place = document.getElementById("errorplace");
    var error_comment = document.getElementById("errorcomment");
    var msg;
  
    if (firstname.length > 10 || firstname == "") {
      msg = "Please enter valid First name";
      error_first.innerHTML = msg;
    }
    if (lastname.length < 5) {
      msg = "Please enter valid Last name";
      error_last.innerHTML = msg;
    }
    if (email.indexOf("@") == -1 || email.length < 7) {
      msg = "Please enter valid Email";
      error_email.innerHTML = msg;
    }
    if (isNaN(phone) || phone.length != 10) {
      msg = "Please enter a valid Phone Number";
      error_phone.innerHTML = msg;
    }
    if (place.length < 5) {
      msg = "Please enter valid Place Name";
      error_place.innerHTML = msg;
    }
    if (comments.length < 30) {
      msg = "Please enter enough comments";
      error_comment.innerHTML = msg;
    }
    if (msg == " ") {
      alert("You have successfully submitted the form!!!");
    } else {
      document.getElementById("quoteform");
      return false;
    }
  }
  