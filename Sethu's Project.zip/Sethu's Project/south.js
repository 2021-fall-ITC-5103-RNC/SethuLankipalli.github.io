$(document).ready(function (){
    $.getJSON("south.json", function (data){
        console.log(data);
        $.each(data.southplaces, function(index, each){
            $("#southcontent" + index).append("<div >"+each.content+"</div>");
           
        });
    });
});
        
  