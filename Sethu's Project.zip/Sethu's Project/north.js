function checkagra(){
    var result = confirm("Would you like to get a quote for Agra?");
    if(result == false)
    {
        event.preventDefault();
    }
}
function checkamritsar(){
    var result = confirm("Would you like to get a quote for Amritsar?");
    if(result == false)
    {
        event.preventDefault();
    }
}
function checkdehradun(){
    var result = confirm("Would you like to get a quote for Deharadun?");
    if(result == false)
    {
        event.preventDefault();
    }
}
function checkdelhi(){
    var result = confirm("Would you like to get a quote for Delhi?");
    if(result == false)
    {
        event.preventDefault();
    }
}
function checkkedarnath(){
    var result = confirm("Would you like to get a quote for Kedarnath?");
    if(result == false)
    {
        event.preventDefault();
    }
}
function checkkullumanali(){
    var result = confirm("Would you like to get a quote for Kullu Manali?");
    if(result == false)
    {
        event.preventDefault();
    }
}